namespace module1{
  export class foo{}
}

var foo = new module1.foo();
console.log(foo);
window.alert("hello kuma");